import subprocess
import psutil

#Funzione per settare la frequenza della CPU Modalità HyperSave ON
def Set_CpuClocks() -> float | str:
    cpuClockString = subprocess.check_output('wmic cpu get MaxClockSpeed')
    frequencyValue = cpuClockString[18:28]
    frequencyValue = int(frequencyValue) / 100
    if psutil.cpu_percent(1) > 70.00:
      return frequencyValue * 100
    elif psutil.cpu_percent(1) < 70.0:
        frequencyValue = frequencyValue * 70
    elif psutil.cpu_percent(1) < 50.0 and psutil.cpu_percent(1) > 30.0:
        frequencyValue = frequencyValue * 50
    elif psutil.cpu_percent(1) < 30.0:
        frequencyValue = frequencyValue * 40
    frequencyValue = hex(int(frequencyValue))
    return frequencyValue


def GetCpuMaxClock() -> float:
    cpuClockString = subprocess.check_output('wmic cpu get MaxClockSpeed')
    frequencyValue = cpuClockString[18:28]
    return frequencyValue