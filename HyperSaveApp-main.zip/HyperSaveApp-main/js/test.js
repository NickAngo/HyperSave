<<<<<<< HEAD
const si = require('systeminformation');

async function monitorNetworkUsage() {
    try {
        const [netIfaces, netStats] = await Promise.all([
            si.networkInterfaces(),
            si.networkStats()
        ]);

        console.clear(); // Pulisce la console per ogni aggiornamento

        netStats.forEach(stat => {
            const ifaceDetails = netIfaces.find(iface => iface.iface === stat.iface);
            if (ifaceDetails && ifaceDetails.speed) {
                const maxSpeedMb = ifaceDetails.speed; // velocità massima in megabit al secondo
                const uploadPercent = (stat.tx_sec / (maxSpeedMb * 125000)) * 100; // Converti in byte al secondo e calcola la percentuale
                const downloadPercent = (stat.rx_sec / (maxSpeedMb * 125000)) * 100;

                let upPerc = uploadPercent.toFixed(2)
                let downPerc = downloadPercent.toFixed(2)
                const averagePercent = (parseFloat(upPerc) + parseFloat(downPerc)) / 2;
                console.log(`Interface: ${stat.iface} - Average Percent: ${averagePercent}`);
            } else {
                console.log(`Interface: ${stat.iface} - No max speed data available`);
            }
        });

    } catch (error) {
        console.error('Error fetching network information:', error);
    }
}

// Esegue la funzione monitorNetworkUsage ogni secondo
setInterval(monitorNetworkUsage, 1000);
=======
const os = require('os');
const si = require('systeminformation');

// Function to get CPU usage
function getCpuUsage() {
    const cpus = os.cpus();
    let idleMs = 0;
    let totalMs = 0;

    cpus.forEach((core) => {
        for (let type in core.times) {
            totalMs += core.times[type];
        }
        idleMs += core.times.idle;
    });

    const idle = idleMs / cpus.length;
    const total = totalMs / cpus.length;
    const usage = ((total - idle) / total) * 100;

    return usage;
}

// Function to get RAM usage
function getRamUsage() {
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const usedMemory = totalMemory - freeMemory;
    const usedMemoryPercentage = (usedMemory / totalMemory) * 100;
    return {
        totalMemory,
        freeMemory,
        usedMemory,
        usedMemoryPercentage
    };
}

// Function to get GPU usage
async function getGpuUsage() {
    try {
        const gpus = await si.graphics();
        return gpus.controllers.map(controller => ({
            name: controller.model,
            usage: controller.load // in percentage
        }));
    } catch (error) {
        console.error('Error getting GPU usage:', error);
        return [];
    }
}

// Function to get network usage
async function getNetworkUsage() {
    try {
        const networkStats = await si.networkStats();
        return networkStats.map(stat => ({
            iface: stat.iface,
            rx_bytes: stat.rx_bytes, // received bytes
            tx_bytes: stat.tx_bytes, // transmitted bytes
            rx_sec: stat.rx_sec, // received bytes per second
            tx_sec: stat.tx_sec // transmitted bytes per second
        }));
    } catch (error) {
        console.error('Error getting network usage:', error);
        return [];
    }
}

// Function to get all system information
async function getSystemUsage() {
    const cpuUsage = getCpuUsage();
    const ramUsage = getRamUsage();
    const gpuUsage = await getGpuUsage();
    const networkUsage = await getNetworkUsage();

    return {
        cpuUsage,
        ramUsage,
        gpuUsage,
        networkUsage
    };
}

// Print the system usage every 5 seconds
setInterval(async () => {
    const systemUsage = await getSystemUsage();
    console.log(systemUsage);
}, 5000);
>>>>>>> origin/Dev
