import time
import win32api

#Funzione per prendere il Tempo dell'inattività di mouse e tastiera
def Get_IncativityTime() -> float:
    return (win32api.GetTickCount() - win32api.GetLastInputInfo()) / 1000.0

#Funzione per il check della tastiera e del mouse Modalità HyperSave ON
<<<<<<< HEAD
def CheckMk(intervallo):
=======
def CheckMk(intervallo) -> bool:
>>>>>>> origin/Dev
    """
    Function to check if the user is away from keyboard.
    """
    try:
        while True:
            inactivity_time = Get_IncativityTime()
            print(inactivity_time)
            time.sleep(1)
            if inactivity_time > intervallo:
                print("è afk")
<<<<<<< HEAD
                return True 
    except Exception as e:
        raise Exception("[Errore] nel sistema di riconoscimento MK") from e

def RevCheckMk(intervallo):
    """
    Function to check if the user is not away from keyboard.
    """
    try:
        while True:
            inactivity_time = Get_IncativityTime()
            print(inactivity_time)
            time.sleep(1)
            if inactivity_time < intervallo:
                print("non è afk")
                return True
    except Exception as e:
        raise Exception("[Errore] nel sistema di riconoscimento MK") from e
=======
                return True
    except Exception as e:
        raise Exception("[Errore] nel sistema di riconoscimento MK") from e

def RevCheckMk(intervallo) -> bool:
    """
    Function to check if the user is not away from keyboard.
    """
    try:
        while True:
            inactivity_time = Get_IncativityTime()
            print(inactivity_time)
            time.sleep(1)
            if inactivity_time < intervallo:
                print("non è afk")
                return True
    except Exception as e:
        raise Exception("[Errore] nel sistema di riconoscimento MK") from e
>>>>>>> origin/Dev
