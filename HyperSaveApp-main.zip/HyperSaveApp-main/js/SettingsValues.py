import json
class Settings:
    """
    Class to store the settings of the application.
    """
    with open("./js/settings.json", "r") as f:
        data = json.load(f)
        inervalKeyboard = data["settings"]["MkInterval"]
        noStopProcess = data["settings"]["NoStopProcess"]
        StartUp = data["settings"]["StartUp"]
        LiteMode = data["settings"]["LiteMode"]
        DefaultMode = data["settings"]["DefaultMode"]
        faceCheck = data["settings"]["faceCheck"]