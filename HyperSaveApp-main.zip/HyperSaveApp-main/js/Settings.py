import os
from win32com.client import Dispatch
from SettingsValues import Settings
#Pulizia del file App.txt per le app che l'utente non vuole fermare

#Menu in bash per l'avvio e il settaggio del programma
def StartOnStartup() -> None:
    if Settings.StartUp:
        try:
            if not os.path.isfile(f"{os.path.expanduser('~')}\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\Hypersave.lnk"):
                path = os.path.join(dir.replace("//","/"), "Hypersave.lnk")
                target = f'{os.getcwd()}\\Essentials\\test.py'
                shell = Dispatch('WScript.Shell')
                shortcut = shell.CreateShortCut(path)
                shortcut.Targetpath = target.replace("//","/")
                shortcut.WorkingDirectory = f'{os.getcwd()}\\Essentials'
                # shortcut.IconLocation = icon
                shortcut.save()
        except:
            pass
    elif Settings.StartUp == "False":
        try:
            os.remove(f'{dir.replace("//","/")}/Hypersave.lnk')
        except:
            pass
