from Import import autoImportProfile
from SettingsValues import *


#Avvio della versione lite del prodotto, di fatti questo non fermerà i processi inutili.
def Lite() -> None:
    autoImportProfile()


Lite()
