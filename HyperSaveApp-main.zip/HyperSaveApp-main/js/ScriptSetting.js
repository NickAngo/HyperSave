const fs = require("fs");
const { ipcRenderer, dialog } = require("electron");


function windowClose() {
  window.open("", "_parent", "");
  window.close();
}

let wsStatus;
let webcamStatus;

window.onload = function () {
  try{
    if(document.getElementById("Table") != null)
      document.getElementById("Table").addEventListener("load",Populate()); 
    document.getElementById("minimize-button").addEventListener("click", () => {
      ipcRenderer.send("minimize-window");
    });
    document.getElementById("close-button").addEventListener("click",windowClose);
    if(document.getElementById("language-select") != null)
      document.getElementById("language-select").addEventListener("change", function () {
        var languageDiv = document.getElementById("language-div");
        languageDiv.textContent = this.value;
      }); 

    buttonStatus();
  }catch (error) {
    alert(error)
  }
}

function buttonStatus(){
  var wsBtn = document.getElementById('ws-btn');
  var wsBtnInner = document.getElementById('ws-btn-inner');
  var webcamBtn = document.getElementById('webcam-btn');
  var webcamBtnInner = document.getElementById('webcam-btn-inner');
  fs.readFile("./js/settings.json", (err, data) => {
    if(err) { 
      alert(err);
      return;
    }
    let tmp = JSON.parse(data);
    if(tmp.settings.StartUp == false) 
    {
      wsBtn.style.background = '#9C70F1';
      wsBtnInner.style.left = '9px';
      swStatus = false;
    }
    else
    {
      wsBtn.style.background = '#6030BD';
      wsBtnInner.style.left = '39px';
      wsStatus = true;
    }
    if(tmp.settings.faceCheck ==false) 
    {
      webcamBtn.style.background = '#9C70F1';
      webcamBtnInner.style.left = '9px';
      webcamStatus = false;
    }
    else
    {
      webcamBtn.style.background = '#6030BD';
      webcamBtnInner.style.left = '39px';
      webcamStatus = true;
    }
    document.getElementById("tbTime").value = tmp.settings.MkInterval/60;
  });
}
//#region JSON

//Status change per il bottone d'avvio
//#endregion

function wsStatusChange(){
  var wsBtn = document.getElementById('ws-btn');
  var wsBtnInner = document.getElementById('ws-btn-inner');
  wsStatus = !wsStatus;

  if(wsStatus) 
  {
    wsBtn.style.background = '#9C70F1';
    wsBtnInner.style.left = '9px';
    
    UpdateStartUp(false);
  }
  else
  {
    wsBtn.style.background = '#6030BD';
    wsBtnInner.style.left = '39px';
    UpdateStartUp(true);
  }
}

function UpdateStartUp(status){
  fs.readFile("./js/settings.json", (err, data) => {
    if(err) { 
      alert(err);
      return;
    }
    
    let tmp = JSON.parse(data);

    tmp.settings.StartUp = status;
    try {
      fs.writeFileSync("./js/settings.json", JSON.stringify(tmp, null, 2));
    } catch (err) {
      alert("Error writing file:", err);
    }
  });
}

function webcamStatusChange(){
  var webcamBtn = document.getElementById('webcam-btn');
  var webcamBtnInner = document.getElementById('webcam-btn-inner');
  webcamStatus = !webcamStatus;

  if(webcamStatus) 
  {
    webcamBtn.style.background = '#9C70F1';
    webcamBtnInner.style.left = '9px';
    UpdateWebcam(false);
  }
  else
  {
    webcamBtn.style.background = '#6030BD';
    webcamBtnInner.style.left = '39px';
    UpdateWebcam(true);
  }
}

function UpdateWebcam(status){
  fs.readFile("./js/settings.json", (err, data) => {
    if(err) { 
      alert(err);
      return;
    }
    
    let tmp = JSON.parse(data);

    tmp.settings.faceCheck = status;
    try {
      fs.writeFileSync("./js/settings.json", JSON.stringify(tmp, null, 2));
    } catch (err) {
      alert("Error writing file:", err);
    }
  });
}
document.getElementById("tbTime").addEventListener("change", timeChange);

function timeChange(){
  let value = parseInt(document.getElementById("tbTime").value);
  if(value > 0 && value < 100){
    fs.readFile("./js/settings.json", (err, data) => {
      if(err) { 
        alert(err);
        return;
      }
      
      let tmp = JSON.parse(data);

      tmp.settings.MkInterval = value * 60;
      try {
        fs.writeFileSync("./js/settings.json", JSON.stringify(tmp, null, 2));
      } catch (err) {
        alert("Error writing file:", err);
      }
    });
  }
}

