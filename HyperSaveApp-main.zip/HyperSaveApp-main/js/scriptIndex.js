const { exec } = require("child_process");
const { ipcRenderer, dialog } = require("electron");
const fs = require("fs");
const si = require("systeminformation");

var HypersaveMode = false;

exec("tasklist", (error, stdout, stderr) => {
  if (error) {
    dialog.showErrorBox("Errore", "Errore durante l'avvio di HyperSave");
    alert(error);
  }
  console.log(stdout);
  if (stdout.includes("python")) {
    HypersaveMode = true;
    document.getElementById("ONorOFF").textContent = "ON";
  } else {
    HypersaveMode = false;
    document.getElementById("ONorOFF").textContent = "OFF";
  }
});

var prestazioni = "Cpu";

<<<<<<< HEAD
=======
var textBoxGrafico = "Values";

document.getElementById("Cpu").addEventListener("click", function () {
  changeBackground("Cpu"); textBoxGrafico = "CPU Values"; 
});
document.getElementById("Gpu").addEventListener("click", function () {
  changeBackground("Gpu"); textBoxGrafico = "GPU Values"; 
});
document.getElementById("Ram").addEventListener("click", function () {
  changeBackground("Ram"); textBoxGrafico = "RAM Values"; 
});
document.getElementById("Net").addEventListener("click", function () {
  changeBackground("Net"); textBoxGrafico = "NET Values"; 
});

>>>>>>> origin/Dev
const datiGrafico = {
  labels: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"],
  datasets: [
    {
<<<<<<< HEAD
      label: "Valori random per testare il funzionamento",
=======
      label: "Values",
>>>>>>> origin/Dev
      backgroundColor: "#6f00ff",
      borderColor: "#6f00ff",
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
  ],
};

const config = {
  type: "line",
  data: datiGrafico,
  options: {
    scales: {
<<<<<<< HEAD
      y: {
        beginAtZero: true,
      },
=======
      yAxes: [{
        display: true,
        ticks: {
          beginAtZero: true,
          steps: 10,
          stepValue: 5,
          max: 100
        }
      }]
>>>>>>> origin/Dev
    },
  },
};

const myChart = new Chart(document.getElementById("myChart"), config);

function windowClose() {
  window.open("", "_parent", "");
  window.close();
}

document.getElementById("minimize-button").addEventListener("click", () => {
  ipcRenderer.send("minimize-window");
});
//#region JSON

window.onload = function () {
  setInterval(monitorSystem, 1000);
<<<<<<< HEAD
  setInterval(() => { myChart.update();}, 1000);
  getPowerPlan();
  liteModeStartUp();
=======
  getPowerPlan();
  liteModeStartUp();
  setInterval(() => { myChart.update();}, 1000);
>>>>>>> origin/Dev
};

//Modifica del file json per le impostazioni
//#region Bottoni Switch


function statusChange() {
  var imgElement = document.getElementById("buttonStart");
  var onOff = document.getElementById("ONorOFF");
<<<<<<< HEAD
  buttonStatus = !buttonStatus;

  if (buttonStatus) {
=======


  if (!HypersaveMode) {
>>>>>>> origin/Dev
    imgElement.src = "./img/POWER_BUTTON.svg";
  } else {
    imgElement.src = "./img/POWER_BUTTON_OFF.svg";
  }
}

//% utilizzo
async function monitorSystem() {
  try {
    const [cpuLoad, memData, gpuData, netStats, netIfaces] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.graphics(),
      si.networkStats(),
      si.networkInterfaces(),
    ]);

    document.getElementById("CpuUsage").textContent =
      cpuLoad.currentLoad.toFixed() + "%";
    document.getElementById("RamUsage").textContent =
      ((memData.used / memData.total) * 100).toFixed() + "%";

    netStats.forEach((stat) => {
      const ifaceDetails = netIfaces.find(
        (iface) => iface.iface === stat.iface,
      );
      if (ifaceDetails && ifaceDetails.speed) {
        const maxSpeedMb = ifaceDetails.speed; // velocità massima in megabit al secondo
        const uploadPercent = (stat.tx_sec / (maxSpeedMb * 125000)) * 100; // Converti in byte al secondo e calcola la percentuale
        const downloadPercent = (stat.rx_sec / (maxSpeedMb * 125000)) * 100;

        let upPerc = uploadPercent.toFixed(2);
        let downPerc = downloadPercent.toFixed(2);
        const averagePercent = (parseFloat(upPerc) + parseFloat(downPerc)) / 2;
        document.getElementById("NetUsage").textContent =
          averagePercent.toFixed() + "%";

        prestazioni.cpu = cpuLoad.currentLoad.toFixed();

        if (prestazioni == "Cpu") {
          datiGrafico.datasets[0].data.push(cpuLoad.currentLoad.toFixed());
        }
        if (prestazioni == "Ram") {
          datiGrafico.datasets[0].data.push(
            ((memData.used / memData.total) * 100).toFixed(),
          );
        }
        gpuData.controllers.forEach((gpu, index) => {
          document.getElementById("GpuUsage").textContent =
            ((gpu.memoryUsed / gpu.memoryTotal) * 100).toFixed() + "%";
          if (prestazioni == "Gpu") {
            datiGrafico.datasets[0].data.push(
              ((gpu.memoryUsed / gpu.memoryTotal) * 100).toFixed(),
            );
          }
        });
        if (prestazioni == "Net") {
          datiGrafico.datasets[0].data.push(averagePercent.toFixed());
        }
        datiGrafico.datasets[0].data.shift();
      }
    });
  } catch (error) {
    console.error("Error fetching system information:", error);
  }
}

//hypersave mode
function StartProcess() {
  try {
<<<<<<< HEAD
=======
    statusChange()
>>>>>>> origin/Dev
    if (!HypersaveMode) {
      HypersaveMode = true;
      exec("python js/StartApp.py", (error, stdout, stderr) => {
        if (error) {
          dialog.showErrorBox("Errore", "Errore durante l'avvio di HyperSave");
          alert(error);
          HypersaveMode = false;
          return;
        }
      });
      alert("HyperSave Avviato con successo");
      document.getElementById("ONorOFF").textContent = "ON";
    } else if (HypersaveMode) {
      document.getElementById("ONorOFF").textContent = "OFF";
      exec("python js/Energency.py", (error, stdout, stderr) => {
        if (error) {
          dialog.showErrorBox("Errore", "Errore durante l'avvio di HyperSave");
          alert(error);
        }
      });
      exec("taskkill /F /IM python.exe", (error, stdout, stderr) => {
        if (error) {
          for (let i = 8; i < 20; i++) {
            exec(
              "taskkill /F /IM python3." + i + ".exe",
              (error, stdout, stderr) => {
                if (!error) {
                  HypersaveMode = false;
                  alert("HyperSave Arrestato con successo");
                  return; // Add this line to exit the loop
                }
              },
            );
          }
        } else {
          HypersaveMode = false;
          alert("HyperSave Arrestato con successo");
          return;
        }
      });
    }
  } catch (error) {
    alert(error);
  }
}

function getPowerPlan() {
  // Execute the powercfg command to get the currently active power plan
  try {
    const output = require("child_process").execSync(
      "powercfg -getactivescheme",
      { encoding: "utf-8" },
    );

    // Extract the GUID of the power plan from the output
    const lines = output.trim().split("\n");
    let guid = null;
    for (const line of lines) {
      if (line.includes("GUID")) {
        const guidAndName = line.split(":")[1].trim();
        guid = guidAndName.split(" (")[0].trim();
        break;
      }
    }

    const configFile = "./js/settings.json";
    const config = JSON.parse(fs.readFileSync(configFile, "utf-8"));

    // Change the value of DefaultMode
    config.settings.DefaultMode = guid; // Replace `True` with the desired value

    // Write the changes back to the JSON file
    fs.writeFileSync(configFile, JSON.stringify(config, null, 4));
  } catch (err) {
    alert(err);
  }
}
//#endregion

//LiteMode
let liteStatus = false;

function liteMode() {
  if (liteStatus) {
    liteStatus = false;
    changeLite(false);
    exec("python js/LiteStop.py", (error, stdout, stderr) => {
      if (error) {
        dialog.showErrorBox("Errore", "Errore durante l'avvio di HyperSave");
        alert(error);
      }
    });
    liteSettings(false);
  } else {
    liteStatus = true;
    changeLite(true);
    exec("python js/LiteStart.py", (error, stdout, stderr) => {
      if (error) {
        dialog.showErrorBox("Errore", "Errore durante l'avvio di HyperSave");
        alert(error);
      }
    });
    liteSettings(true);
  }
}

function changeLite(status) {
  let liteModeSwitchBg = document.getElementById("liteModeBg");
  let liteModeSwitchInner = document.getElementById("liteModeInner");
  let liteModeSwitchText = document.getElementById("liteModeText");

  //controlla lo stato che deve attuare
  if (status) {
    liteModeSwitchInner.style.left = "55px";
    liteModeSwitchBg.style.backgroundColor = "#6030BD";
  } else {
    liteModeSwitchInner.style.left = "10px";
    liteModeSwitchBg.style.backgroundColor = "#9888a8";
  }
}

function liteModeStartUp() {
  fs.readFile("./js/settings.json", (err, data) => {
    if (err) {
      alert(err);
      return;
    }

    let tmp = JSON.parse(data);

    let status = tmp.settings.LiteMode;
    if (status) {
      changeLite(true);
      liteMode();
    }
  });
}

function liteSettings(status) {
  fs.readFile("./js/settings.json", (err, data) => {
    if (err) {
      alert(err);
      return;
    }

    let tmp = JSON.parse(data);

    tmp.settings.LiteMode = status;
    try {
      fs.writeFileSync("./js/settings.json", JSON.stringify(tmp, null, 2));
    } catch (err) {
      alert("Error writing file:", err);
    }
  });
}

function changeBackground(id) {
  var cazzo = document.querySelectorAll(".status-button");
  cazzo.forEach(function (cazzo) {
<<<<<<< HEAD
    cazzo.style.background = "#1E1E2B";
=======
    cazzo.style.background = "#242635";
>>>>>>> origin/Dev
  });

  document.getElementById(id).style.background = "#6030BD";
  prestazioni = id;
  datiGrafico.datasets[0].data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
}

<<<<<<< HEAD
document.getElementById("Cpu").addEventListener("click", function () {
  changeBackground("Cpu");
});
document.getElementById("Gpu").addEventListener("click", function () {
  changeBackground("Gpu");
});
document.getElementById("Ram").addEventListener("click", function () {
  changeBackground("Ram");
});
document.getElementById("Net").addEventListener("click", function () {
  changeBackground("Net");
});
=======

>>>>>>> origin/Dev
