import cv2
import time
import os
import SettingsValues

#Funzione per il detect della fotocamera con parametri classifier e intervallo:
#classifier serve per "classificare" i diversi oggetti.
#Intervallo per il frangente di tempo per il quale il software debba cercare la persona al PC
<<<<<<< HEAD
def detect_objects(classifier, intervallo):
=======
def detect_objects(classifier, intervallo) -> bool | None:
>>>>>>> origin/Dev
    """
    Function to detect objects using a classifier.
    """
    # Initialize the number of checks and the check flag
    number_of_checks = 0
    check = False

    # Open the webcam
    webcam = cv2.VideoCapture(0)

    if webcam.isOpened():
        while True:
            # Read a frame from the webcam
            ret, frame = webcam.read()

            # Convert the frame to grayscale
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            # Detect objects in the frame
            objects = classifier.detectMultiScale(gray, scaleFactor=1.6, minNeighbors=2)

            for (x, y, w, h) in objects:
                # Draw a rectangle around the object
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

                # Set the check flag to True and reset the number of checks
                check = True
                number_of_checks = 0

                print("Ho trovato un viso!")
                time.sleep(10)
                return True

            # If no objects were found, increment the number of checks
            if not check:
                number_of_checks += 1
                time.sleep(0.5)

                # If the number of checks reaches the interval, return False
                if number_of_checks == intervallo:
                    print("Non ho trovato nessuno, il pc verrà messo in modalità HyperSave")
                    return False

            # If 'q' is pressed, break the loop
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        # Release the webcam and destroy all windows
        webcam.release()
        cv2.destroyAllWindows()

    else:
        return False
#Funzione Per avviare il programma
def StartSession():
    if SettingsValues.Settings.faceCheck:
        cascade_object = cv2.CascadeClassifier(f'{os.getcwd()}\\js\\Essentials\\haarcascade_frontalface_default.xml')
        return detect_objects(cascade_object,int(10))
<<<<<<< HEAD
        
=======
>>>>>>> origin/Dev
