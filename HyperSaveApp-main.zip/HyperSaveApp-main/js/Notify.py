from plyer import notification
import os

#Inviare la notifica all'utente dell'avvio di HyperSave ON
def notif(codice) -> None:
    if codice == 0:
        notification.notify(
            title='HyperSave Mode ON',
            message='La Modalità di HyperSave è stata inizializzata con successo!',
            app_icon=None,
        )
        
#Inviare la notifica all'utente dell'avvio di HyperSave OFF

    elif codice == 1:
            notification.notify(
            title='HyperSave Mode OFF',
            message=f'Bentornato {os.getlogin()}, La Modalità di HyperSave è Stata Disattivata con Successo!',
            app_icon=None,
        )