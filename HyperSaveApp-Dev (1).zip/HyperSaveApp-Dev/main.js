const { app, BrowserWindow } = require("electron");
const path = require("path");
const url = require("url");
fs = require("fs");

let win;

function createWindow() {
  win = new BrowserWindow({
    icon: path.join(__dirname, "icon.ico"),
    titleBarStyle: "hidden",
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
    minimizable: true,
  });

  win.setSize(1265, 825);

  win.setMaximumSize(1265, 825);

  win.setMinimumSize(1265, 825);

  win.setMenuBarVisibility(false);

  win.loadURL(
    url.format({
      pathname: path.join(__dirname, "index.html"),
      protocol: "file",
      slashes: true,
      frame: false,
    }),
  );

  win.on("closed", () => {
    win = null;
  });
}

app.on("ready", createWindow);

const { ipcMain } = require("electron");
ipcMain.on("minimize-window", () => {
  win.minimize();
});
