from ControlloMK import CheckMk, RevCheckMk
from Conversione import Set_CpuClocks
from findHexId import findId
from Fotocamera import StartSession
from Import import autoImportProfile
from Suspension import SuspendProcesses, ResumeProcesses
from Notify import notif
from Emergency import Emergency
from Settings import StartOnStartup
from SettingsValues import *
import screen_brightness_control as sbc
import os
import time
import subprocess
import tkinter as tk


intervallo = Settings.inervalKeyboard
x = subprocess.getoutput(["powershell.exe","Get-ComputerInfo","-Property","PowerPlatformRole"])
current_plan = Settings.DefaultMode

if not "Desktop" in x:
    britghtnessValues = sbc.get_brightness()
    prevBright = int(britghtnessValues[0])

#Utilizzo di tutte le varie funzioni create in precedenza
def Start():
    """
    Function to start the application, manage power saving mode and handle exceptions.
    """
    try:
        HyperSaveMode = False
        while True:
            if not HyperSaveMode:
                if CheckMk(intervallo=intervallo) and not StartSession():
                    StartOnStartup()
                    time.sleep(2)
                    autoImportProfile()

                    if "Desktop" not in x:
                        os.system('powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,1)"')

                    os.system(f"powercfg -setdcvalueindex {findId()} SUB_PROCESSOR PROCFREQMAX {Set_CpuClocks()}")
                    SuspendProcesses()
                    notif(0)
                    HyperSaveMode = True
            else:
                if RevCheckMk(intervallo):
                    HyperSaveMode = False

                    if "Desktop" not in x:
                        os.system(f'powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{prevBright})"')

                    os.system(f'powercfg -setactive {current_plan}')
                    notif(1)
                    ResumeProcesses()
    except Exception as e:
        print(e)
        Emergency()


Start()
