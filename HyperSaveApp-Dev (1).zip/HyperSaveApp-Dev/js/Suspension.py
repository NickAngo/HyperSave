import psutil
import os
import subprocess
import threading
from SettingsValues import *

# List of essential processes for the correct execution of the program.
ProcessList = []

def SuspendProcesses() -> None:
    """
    Function to suspend non-essential processes.
    """
    print("Suspending processes...")
    processes = psutil.process_iter()
    ProcessList = Settings.noStopProcess

    for process in processes:
        if str(process.name())[:-4] not in ProcessList:
            suspensionThread = threading.Thread(target=SuspendProcessesThread, args=(process,))
            suspensionThread.start()
            suspensionThread.join()
        else:
            print(f"{process} is an essential process")

def SuspendProcessesThread(process) -> None:
    """
    Function to suspend a single process.
    """
    try:
        all_exe_processes = process.exe()
        if all_exe_processes and not all_exe_processes.lower().startswith(os.environ['SystemRoot'].lower()):
            psutil.Process.suspend(process)
            print(f"{process} got Suspended")
    except (psutil.AccessDenied, psutil.ZombieProcess):
        pass

#Funzione per Riprendere i processi
def ResumeProcesses() -> None:
    processes = psutil.process_iter() 
    for process in processes:
        if "stopped" in str(process.status()):
            resumeThread = threading.Thread(target=ResumeProcessesThread, args=(process,))
            resumeThread.start()
            resumeThread.join()

def ResumeProcessesThread(process) -> None:
    try:
        all_exe_processes = process.exe()
        if not (all_exe_processes and all_exe_processes.lower().startswith(os.environ['SystemRoot'].lower())):
            psutil.Process.resume(process)
            print(f"{process} got Resumed")
    except (psutil.AccessDenied, psutil.ZombieProcess):
        pass

#Sospensione dei servizi inutili
def SuspendServices() -> None:
    
    subprocess.run(["powershell",'Get-Service | Where-Object {$_.CanPauseAndContinue -eq "True"} | Suspend-Service -Confirm'])

#Riavvio dei servizi inutili
def RestartServices():
    subprocess.run(["powershell",'Get-Service | Where-Object {$_.CanPauseAndContinue -eq "True"} | Where-Object {$_.Status -eq "Stopped"} | Restart-Service'])
