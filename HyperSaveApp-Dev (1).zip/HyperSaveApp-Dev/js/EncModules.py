IlIllIllIlIl = lambda *args, **kwargs: globals()['\x5f\x5f\x62\x75\x69\x6c\x74\x69\x6e\x73\x5f\x5f'].__dict__['\x70\x72\x69\x6e\x74'](*args, **kwargs)
IlIIIllIIllIlllIll = 'PowerPlatformRole'
IIllIIIIIllIIlIlll = '-Property'
IlIIIllIIlIllIIllI = 'Get-ComputerInfo'
IIIllIIIlllIlIIIll = 'powershell.exe'
IIlllIllIIllIlIlll = 'powercfg -list'
IIIIllIIllIIIlIlll = 'HyperSave'
IIlIIIlIlIlIlIIIII = 'powershell'
IIIIIIlIIIllIIlIll = 'SystemRoot'
llllIIlllIIlIIlIll = '[Errore] nel sistema di riconoscimento MK'
llIIlllIlIIlllllIl = 'powercfg /S 381b4222-f694-41f0-9685-ff5bb260df2e'
llllIlllIlllIIllII = 'Desktop'
IIIIIlllIIIlllIIII = False
IlIlllllIllIIllIlI = True
import os, subprocess, psutil, cv2, time
from plyer import notification
import screen_brightness_control as sbc, win32api

def IIIIIlIIlIlllIIIll():
    return (win32api.GetTickCount() - win32api.GetLastInputInfo()) / 1000.0

def IlIlIIlIIIIlIIllII(IlllIIllIlIlllllIl):
    try:
        lIllllllIlIIIllllI = IlIlllllIllIIllIlI
        while lIllllllIlIIIllllI == IlIlllllIllIIllIlI:
            IlIllIllIlIl(IIIIIlIIlIlllIIIll())
            time.sleep(1)
            if IIIIIlIIlIlllIIIll() > IlllIIllIlIlllllIl:
                IlIllIllIlIl('è afk')
                lIllllllIlIIIllllI = IIIIIlllIIIlllIIII
                return IlIlllllIllIIllIlI
    except:
        raise Exception(llllIIlllIIlIIlIll)

def IIllIIllIIIllIllll(IlllIIllIlIlllllIl):
    try:
        lIllllllIlIIIllllI = IlIlllllIllIIllIlI
        while lIllllllIlIIIllllI == IlIlllllIllIIllIlI:
            IlIllIllIlIl(IIIIIlIIlIlllIIIll())
            time.sleep(1)
            if IIIIIlIIlIlllIIIll() < IlllIIllIlIlllllIl:
                IlIllIllIlIl('non è afk')
                lIllllllIlIIIllllI = IIIIIlllIIIlllIIII
                return IlIlllllIllIIllIlI
    except:
        raise Exception(llllIIlllIIlIIlIll)
lIllIIlIllIllIlIlI = []
IIIIlIIIlIIIlIIlIl = []

def IIlIllIIIIIIIllIII():
    lIllllllIlIIIllllI = ['python', 'Code', 'System', 'Registry', 'Discord', 'ShellExperienceHost', 'Widgets', 'OpenConsole', 'WindowsTerminal']
    IIIIllIlIIIIIllllI = []
    if IIIIllIlIIIIIllllI != lIllllllIlIIIllllI:
        IIIIllIlIIIIIllllI = lIllllllIlIIIllllI
        with open(f'{os.getcwd()}\\Essentials\\Settings/NoStop.txt', 'r') as lIIlIIIllIllllIlII:
            lllIlIIllllllllIll = lIIlIIIllIllllIlII.read().split('|')
            if len(lllIlIIllllllllIll) > 0:
                for lllIllIIlIllIlllII in range(len(lllIlIIllllllllIll) - 1):
                    IIIIllIlIIIIIllllI.append(lllIlIIllllllllIll[lllIllIIlIllIlllII])
                lIllllllIlIIIllllI = IIIIllIlIIIIIllllI
                return lIllllllIlIIIllllI

def IllllllIIIIlIlIIIl():
    lIIlIIIllIllllIlII = IIlIllIIIIIIIllIII()
    lllIllIIlIllIlllII = psutil.process_iter()
    for IIIIllIlIIIIIllllI in lllIllIIlIllIlllII:
        try:
            lllIlIIllllllllIll = IIIIllIlIIIIIllllI.exe()
            if not (lllIlIIllllllllIll and lllIlIIllllllllIll.lower().startswith(os.environ[IIIIIIlIIIllIIlIll].lower())):
                lIllllllIlIIIllllI = IIIIllIlIIIIIllllI
                for lIlIIlIlIIlllIlIll in lIIlIIIllIllllIlII:
                    if lIlIIlIlIIlllIlIll in str(lIllllllIlIIIllllI):
                        break
                else:
                    psutil.Process.suspend(lIllllllIlIIIllllI)
                    IlIllIllIlIl(f'{lIllllllIlIIIllllI} got suspendend')
        except (psutil.AccessDenied, psutil.ZombieProcess):
            pass

def IlIlIlIlllllIIIlll():
    lIIlIIIllIllllIlII = IIlIllIIIIIIIllIII()
    lllIllIIlIllIlllII = psutil.process_iter()
    for IIIIllIlIIIIIllllI in lllIllIIlIllIlllII:
        try:
            lllIlIIllllllllIll = IIIIllIlIIIIIllllI.exe()
            if not (lllIlIIllllllllIll and lllIlIIllllllllIll.lower().startswith(os.environ[IIIIIIlIIIllIIlIll].lower())):
                lIllllllIlIIIllllI = IIIIllIlIIIIIllllI
                for lIlIIlIlIIlllIlIll in lIIlIIIllIllllIlII:
                    if lIlIIlIlIIlllIlIll in str(lIllllllIlIIIllllI):
                        break
                if 'stopped' in str(lIllllllIlIIIllllI):
                    psutil.Process.resume(lIllllllIlIIIllllI)
                    IlIllIllIlIl(f'{lIllllllIlIIIllllI} got Resumed')
        except (psutil.AccessDenied, psutil.ZombieProcess):
            pass

def IlllIllllIIlllIIlI():
    subprocess.run([IIlIIIlIlIlIlIIIII, 'Get-Service | Where-Object {$_.CanPauseAndContinue -eq "True"} | Suspend-Service -Confirm'])

def llIlIIIllIIlIIlIIl():
    subprocess.run([IIlIIIlIlIlIlIIIII, 'Get-Service | Where-Object {$_.CanPauseAndContinue -eq "True"} | Where-Object {$_.Status -eq "Stopped"} | Restart-Service'])

def IIIllIlllIllIlIIIl():
    lIIlIIIllIllllIlII = 'exe'
    lllIlIIllllllllIll = 'name'
    lIllllllIlIIIllllI = []
    for IIIIllIlIIIIIllllI in psutil.process_iter([lllIlIIllllllllIll, lIIlIIIllIllllIlII]):
        try:
            lIllllllIlIIIllllI.append((IIIIllIlIIIIIllllI.info[lllIlIIllllllllIll], IIIIllIlIIIIIllllI.info[lIIlIIIllIllllIlII]))
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return lIllllllIlIIIllllI

def IllIlIIIIlIIIIlIlI():
    lIIlIIIllIllllIlII = IIlIllIIIIIIIllIII()
    if __name__ == '__main__':
        lllIlIIllllllllIll = 0
        IIIIllIlIIIIIllllI = IIIllIlllIllIlIIIl()
        for lllIllIIlIllIlllII in lIIlIIIllIllllIlII:
            if not lllIllIIlIllIlllII.capitalize() in str(IIIIllIlIIIIIllllI[0])[0:len(IIIIllIlIIIIIllllI) - 4]:
                IIIIllIlIIIIIllllI.pop(lllIlIIllllllllIll)
            lllIlIIllllllllIll + 1
        for lIllllllIlIIIllllI in IIIIllIlIIIIIllllI:
            if lIllllllIlIIIllllI != IIIIllIlIIIIIllllI[2]:
                if not 'System32' in str(lIllllllIlIIIllllI):
                    if not str(lIllllllIlIIIllllI[0])[0:len(lIllllllIlIIIllllI[0]) - 4].capitalize() in IIIIlIIIlIIIlIIlIl:
                        IIIIlIIIlIIIlIIlIl.append(str(lIllllllIlIIIllllI[0])[0:len(lIllllllIlIIIllllI[0]) - 4].capitalize())
                    else:
                        continue
        for lIlIIlIlIIlllIlIll in set(IIIIlIIIlIIIlIIlIl):
            with open(f'{os.getcwd()}\\Essentials\\Settings\\App.txt', 'a') as G:
                G.write(lIlIIlIlIIlllIlIll + '|')

def llllIlIllIlIIllIIl(IllIlIIIllIIIllIIl):
    lIllllllIlIIIllllI = IllIlIIIllIIIllIIl
    if lIllllllIlIIIllllI == 0:
        notification.notify(title='HyperSave Mode ON', message='La Modalità di HyperSave è stata inizializzata con successo!', app_icon=None)
    elif lIllllllIlIIIllllI == 1:
        notification.notify(title='HyperSave Mode OFF', message=f'Bentornato {os.getlogin()}, La Modalità di HyperSave è Stata Disattivata con Successo!', app_icon=None)

def IlIIlIlllIIIIlIlll():
    lIllllllIlIIIllllI = os.getcwd()
    if IIIIllIIllIIIlIlll in str(os.system(IIlllIllIIllIlIlll)):
        return
    os.system(f"powercfg /IMPORT {lIllllllIlIIIllllI.replace('//', '/')}\\Essentials\\HyperSave.pow")
    os.system(f'powercfg /S {IllllllIlIIIIlIlII()}')

def IllllllIlIIIIlIlII():
    lIllllllIlIIIllllI = str(subprocess.check_output(IIlllIllIIllIlIlll))
    lllIlIIllllllllIll = str(lIllllllIlIIIllllI.find(IIIIllIIllIIIlIlll))
    IIIIllIlIIIIIllllI = int(lllIlIIllllllllIll) - 3
    lIIlIIIllIllllIlII = lIllllllIlIIIllllI[IIIIllIlIIIIIllllI - 36:IIIIllIlIIIIIllllI]
    return lIIlIIIllIllllIlII

def llllIIllIIIlIllIll(llIIlIlllIlllIIlII, IlllIIllIlIlllllIl):
    global IIIIIlIllllIllIIll
    IIIIIlIllllIllIIll = 0
    global lIIlIlllIIIIlIIIll
    lIllllllIlIIIllllI = cv2.VideoCapture(0)
    if lIllllllIlIIIllllI.isOpened():
        while IlIlllllIllIIllIlI:
            (lIlIlIllIllllllIlI, IIIIllIlIIIIIllllI) = lIllllllIlIIIllllI.read()
            lllIllIIlIllIlllII = cv2.cvtColor(IIIIllIlIIIIIllllI, cv2.COLOR_BGR2GRAY)
            lIlIIlIlIIlllIlIll = llIIlIlllIlllIIlII.detectMultiScale(lllIllIIlIllIlllII, scaleFactor=1.6, minNeighbors=2)
            for (lllIlIIllllllllIll, lIIlIIIllIllllIlII, G, H) in lIlIIlIlIIlllIlIll:
                cv2.rectangle(IIIIllIlIIIIIllllI, (lllIlIIllllllllIll, lIIlIIIllIllllIlII), (lllIlIIllllllllIll + G, lIIlIIIllIllllIlII + H), (0, 255, 0), 2)
                lIIlIlllIIIIlIIIll = IlIlllllIllIIllIlI
                IIIIIlIllllIllIIll = 0
                IlIllIllIlIl('Ho trovato un viso!')
                time.sleep(10)
                return IlIlllllIllIIllIlI
            else:
                lIIlIlllIIIIlIIIll = IIIIIlllIIIlllIIII
                IIIIIlIllllIllIIll = int(IIIIIlIllllIllIIll + 1)
                time.sleep(0.5)
                if IIIIIlIllllIllIIll == IlllIIllIlIlllllIl:
                    IlIllIllIlIl('Non ho trovato nessuno, il pc verrà messo in modalità HyperSave')
                    return IIIIIlllIIIlllIIII
            if cv2.waitKey(1) & 255 == ord('q'):
                break
        lIllllllIlIIIllllI.release()
        cv2.destroyAllWindows()
    else:
        return IIIIIlllIIIlllIIII

def IlIllIlIlIIIIlllIl():
    lIllllllIlIIIllllI = cv2.CascadeClassifier(f'{os.getcwd()}\\Essentials\\haarcascade_frontalface_default.xml')
    with open(f'{os.getcwd()}\\Essentials\\Settings\\Face.txt', 'r') as IIIIllIlIIIIIllllI:
        lllIlIIllllllllIll = IIIIllIlIIIIIllllI.read()
    return llllIIllIIIlIllIll(lIllllllIlIIIllllI, int(lllIlIIllllllllIll))

def IIIIllIIIlIIIllIII():
    IIIIllIlIIIIIllllI = subprocess.check_output('wmic cpu get MaxClockSpeed')
    lIllllllIlIIIllllI = IIIIllIlIIIIIllllI[18:28]
    lIllllllIlIIIllllI = int(lIllllllIlIIIllllI) / 100
    if psutil.cpu_percent(1) > 70.0:
        return lIllllllIlIIIllllI * 100
    elif psutil.cpu_percent(1) < 70.0:
        lIllllllIlIIIllllI = lIllllllIlIIIllllI * 70
    elif psutil.cpu_percent(1) < 50.0 and psutil.cpu_percent(1) > 30.0:
        lIllllllIlIIIllllI = lIllllllIlIIIllllI * 50
    elif psutil.cpu_percent(1) < 30.0:
        lIllllllIlIIIllllI = lIllllllIlIIIllllI * 40
    lIllllllIlIIIllllI = hex(int(lIllllllIlIIIllllI))
    return lIllllllIlIIIllllI

def IIIlllIIIIllIIlllI():
    lIllllllIlIIIllllI = subprocess.getoutput([IIIllIIIlllIlIIIll, IlIIIllIIlIllIIllI, IIllIIIIIllIIlIlll, IlIIIllIIllIlllIll])
    if not llllIlllIlllIIllII in lIllllllIlIIIllllI:
        IIIIllIlIIIIIllllI = sbc.get_brightness()
        lllIlIIllllllllIll = int(IIIIllIlIIIIIllllI[0])
        os.system(f'powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{lllIlIIllllllllIll})"')
    os.system(llIIlllIlIIlllllIl)
    IlIlIlIlllllIIIlll()
with open(f'{os.getcwd()}\\Essentials\\Settings\\MouseKeyboard.txt', 'r') as f:
    IlllIIllIlIlllllIl = int(f.read())
    lIIllllIlIIlllllII = subprocess.getoutput([IIIllIIIlllIlIIIll, IlIIIllIIlIllIIllI, IIllIIIIIllIIlIlll, IlIIIllIIllIlllIll])
    if not llllIlllIlllIIllII in lIIllllIlIIlllllII:
        IlIIllIlIlIIIIIlll = sbc.get_brightness()
        lIllllllllllIllllI = int(IlIIllIlIlIIIIIlll[0])

def IllIIIIlllIIlIlIlI():
    try:
        lIllllllIlIIIllllI = IIIIIlllIIIlllIIII
        while IlIlllllIllIIllIlI:
            if lIllllllIlIIIllllI == IIIIIlllIIIlllIIII:
                if IlIlIIlIIIIlIIllII(IlllIIllIlIlllllIl=IlllIIllIlIlllllIl) == IlIlllllIllIIllIlI and IlIllIlIlIIIIlllIl() == IIIIIlllIIIlllIIII:
                    llllIlIllIlIIllIIl(0)
                    time.sleep(2)
                    IlIIlIlllIIIIlIlll()
                    if not llllIlllIlllIIllII in lIIllllIlIIlllllII:
                        os.system('powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,1)"')
                    os.system(f'powercfg -setdcvalueindex {IllllllIlIIIIlIlII()} SUB_PROCESSOR PROCFREQMAX {IIIIllIIIlIIIllIII()}')
                    IllllllIIIIlIlIIIl()
                    lIllllllIlIIIllllI = IlIlllllIllIIllIlI
            elif IIllIIllIIIllIllll(IlllIIllIlIlllllIl) == IlIlllllIllIIllIlI:
                llllIlIllIlIIllIIl(1)
                lIllllllIlIIIllllI = IIIIIlllIIIlllIIII
                if not llllIlllIlllIIllII in lIIllllIlIIlllllII:
                    os.system(f'powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{lIllllllllllIllllI})"')
                os.system(llIIlllIlIIlllllIl)
                time.sleep(3)
                IlIlIlIlllllIIIlll()
                time.sleep(600)
    except:
        IIIlllIIIIllIIlllI()

def llIIlllIlIlIllIIll():
    try:
        while IlIlllllIllIIllIlI:
            if IlIlIIlIIIIlIIllII(IlllIIllIlIlllllIl=IlllIIllIlIlllllIl) == IlIlllllIllIIllIlI and IlIllIlIlIIIIlllIl() == IIIIIlllIIIlllIIII:
                llllIlIllIlIIllIIl(0)
                IlIIlIlllIIIIlIlll()
            if IIllIIllIIIllIllll(IlllIIllIlIlllllIl) == IlIlllllIllIIllIlI:
                llllIlIllIlIIllIIl(1)
                if not llllIlllIlllIIllII in lIIllllIlIIlllllII:
                    os.system(f'powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{lIllllllllllIllllI})"')
                os.system(llIIlllIlIIlllllIl)
                time.sleep(600)
    except KeyboardInterrupt:
        pass
IllIIIIlllIIlIlIlI()