from Import import autoImportProfile, get_current_power_plan
from Notify import notif
from SettingsValues import *
import os
import json
import time


#Avvio della versione lite del prodotto, di fatti questo non fermerà i processi inutili.
def StopLite() -> None:
    current_plan = Settings.DefaultMode
    try:
        os.system(f'powercfg -setactive {current_plan}')
    except KeyboardInterrupt:
        pass

StopLite()
