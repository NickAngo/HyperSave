const { exec } = require("child_process");
const fs = require("fs");
const { ipcRenderer, dialog } = require("electron");
const { promiseHooks } = require("v8");

function windowClose() {
    window.open("", "_parent", "");
    window.close();
}

const excludeStrings = ['System', "Registry", 'smss', 'csrss',"wininit","services","svchost","lsass","winlogon","fontdrvhost","dwm","explorer","taskhostw","SearchIndexer","RuntimeBroker","SecurityHealthService","SettingSyncHost","ShellExperienceHost","sihost","smartscreen","spoolsv","svchost"]; 

window.onload = function () {
    try{
        if(document.getElementById("TableBody") != null)
            document.getElementById("TableBody").addEventListener("load",Populate());
        document.getElementById("minimize-button").addEventListener("click", () => {
        ipcRenderer.send("minimize-window");
        });
        document.getElementById("close-button").addEventListener("click",windowClose);

    }catch (error) {
        alert(error)
    }
}

let selectedProcesses = []
const table = document.getElementById("Table");
const tableContainer = document.getElementById("tableContainer");

const thead = table.querySelector("thead");
const tbody = table.querySelector("tbody");
const tbodyHeight = tbody.clientHeight;
const theadHeight = thead.clientHeight;
const newTbodyHeight = tbodyHeight - theadHeight;
tbody.style.height = `${newTbodyHeight}px`;

function getProcesses() {
try {
  return new Promise((resolve, reject) => {
    exec('wmic process get Name,processid', (error, stdout, stderr) => {
      if (error) {
        reject(error);
      } else {
        const lines = stdout.split('\n');
        const processMap = new Map();
        lines.slice(1).forEach(line => {
          const [name, pid] = line.trim().split(/\s+/);
          const nome = name.split(".")[0];
          if (!processMap.has(nome) && !excludeStrings.some(excludeString => nome.includes(excludeString))) {
            processMap.set(nome, pid);
          }
        });
        const processes = Array.from(processMap, ([name, pid]) => `${name}.${pid}`);
        resolve(processes);
      }
    });
  });
}
  catch (error) {
    alert(error)
  }
}

function Populate(){
  try{
    fs.readFile("./js/settings.json", (err, data) => {
      if(err) { 
        alert(err);
        return;
      }
      
      let tmp = JSON.parse(data);
      
      // Ensure tmp.settings.NoStopProcess is an array
      if (!tmp.settings || !Array.isArray(tmp.settings.NoStopProcess)) {
        alert("Invalid JSON structure");
        return;
      }
      noStop = tmp.settings.NoStopProcess;
    
      getProcesses().then(temp => {
        let count = 0;
        temp.forEach(element => {
          count++;
          if(element == "")
            return
          if(noStop.includes(element.split(".")[0])) {
            insertElements(element.split(".")[0],element.split(".")[1],"Low",true)
          }else{
            insertElements(element.split(".")[0],element.split(".")[1],"Low",false)
          }
        });
        checkrows()
      })
    });
  }catch (error) {
    alert(error)
  }
}
function UpdateJsonFile(){
  fs.readFile("./js/settings.json", (err, data) => {
    if(err) { 
      alert(err);
      return;
    }
    
    let tmp = JSON.parse(data);
    
    // Ensure tmp.settings.NoStopProcess is an array
    if (!tmp.settings || !Array.isArray(tmp.settings.NoStopProcess)) {
      alert("Invalid JSON structure");
      return;
    }
    tmp.settings.NoStopProcess =selectedProcesses;
    try {
      fs.writeFileSync("./js/settings.json", JSON.stringify(tmp, null, 2));
    } catch (err) {
      alert("Error writing file:", err);
    }
  });
}

function checkrows(){
  const maxRows = 4;
  const rows = table.rows;
  if (rows.length > maxRows) {
    for (let i = maxRows; i < rows.length; i++) {
      rows[i].remove();
    }
  }
  if (rows.length > maxRows) {
    tableContainer.style.overflowY = "scroll";
  } else {
    tableContainer.style.overflowY = "hidden";
  }
}

function insertElements(nome, pid, priority, noStop) {

  try{
  // Ottieni l'elemento tbody con l'ID "TableBody"
  const tableBody = document.getElementById("TableBody");

  // Crea un nuovo elemento tr
  const tr = document.createElement("tr");
  tr.className = "border border-gray-700 hover:bg-gray-50 hover:bg-gray-600";

  // Crea e aggiungi i vari elementi td e th al tr
  const td1 = document.createElement("td");
  td1.className = "w-4 p-8 pl-9";

  const div1 = document.createElement("div");
  div1.className = "flex items-center";

  const input = document.createElement("input");
  input.id = "checkbox-table-search-1";
  input.checked = noStop;
  input.type = "checkbox";
  input.className = "w-4 h-4 text-white bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-blue-600 ring-offset-gray-800 focus:ring-offset-gray-800 focus:ring-2 bg-gray-700 border-gray-600";
  input.addEventListener("change", () => {
    // Read the existing data from the JSON file
    fs.readFile('./js/settings.json', (err, data) => {
        if (err) {
            alert(err);
        }

        // Parse the JSON data to an array
        tmp = JSON.parse(data);
        selectedProcesses = tmp.settings.NoStopProcess;

        if (input.checked) {
            // Add the new process to the array
            selectedProcesses.push(nome);
        } else {
            // Remove the process from the array
            selectedProcesses = selectedProcesses.filter(process => process !== nome);
        }

        // Update the JSON file
        UpdateJsonFile();
    });
});
  const label = document.createElement("label");
  label.htmlFor = "checkbox-table-search-1";
  label.className = "sr-only";

  label.textContent = "checkbox";

  div1.appendChild(input);
  div1.appendChild(label);
  td1.appendChild(div1);
  tr.appendChild(td1);

  // Crea e aggiungi gli elementi th
  const th = document.createElement("th");
  th.scope = "row";
  th.className = "flex items-center px-6 py-4 text-gray-900 whitespace-nowrap text-white";

  const div2 = document.createElement("div");
  div2.className = "ps-3";

  const div3 = document.createElement("div");
  div3.className = "text-base font-semibold text-white";
  div3.textContent = nome;

  div2.appendChild(div3);
  th.appendChild(div2);
  tr.appendChild(th);

  // Crea e aggiungi gli elementi td
  const td2 = document.createElement("td");
  td2.className = "px-6 py-4";
  td2.textContent = pid;

  const td3 = document.createElement("td");
  td3.className = "px-6 py-4";

  const div4 = document.createElement("div");
  div4.className = "flex items-center";

  const div5 = document.createElement("div");
  div5.className = "h-2.5 w-2.5 rounded-full bg-green-500 me-2";

  div4.appendChild(div5);
  td3.appendChild(div4);
  td3.textContent += " " + priority;

  tr.appendChild(td2);
  tr.appendChild(td3);

  // Aggiungi il tr al tbody
  tableBody.appendChild(tr);
  }catch (error) {
    alert(error)
  }
}