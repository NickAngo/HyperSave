import subprocess

#Funzione per trovare l'id del profilo energetico in esadecimale (Hex) HyperSave ON
def findId() -> str:
   """
    Function to find the id of the power profile in hexadecimal (Hex) HyperSave ON
   """
   power_profile_name = str(subprocess.check_output('powercfg -list'))
   index_hypersave_power_configuration = str(power_profile_name.find("HyperSave"))
   end_of_string_power_profile_name = (int(index_hypersave_power_configuration) - 3)
   hex_hypersave_value = power_profile_name[end_of_string_power_profile_name-36:end_of_string_power_profile_name]
   return hex_hypersave_value
