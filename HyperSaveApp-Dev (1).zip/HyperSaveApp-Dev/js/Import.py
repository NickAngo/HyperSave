import os
import subprocess
import json
from findHexId import findId


#Funzione per importare Il profilo energetico
def autoImportProfile() -> None:
    current_directory = os.getcwd()
    output = subprocess.check_output("powercfg -list", shell=True, text=True)

    # Cerca il nome del power plan nell'elenco
    if "HyperSave" in output:
        os.system(f"powercfg -setactive {findId()}")
    else:
        output = subprocess.check_output(f"powercfg /IMPORT {current_directory.replace('//', '/')}\Essentials\HyperSave.pow", shell=True, text=True)
        os.system(f'powercfg -changename {output[-36:]} "HyperSave"')
        os.system(f"powercfg -setactive {findId()}")


def get_current_power_plan():
    # Apre il file JSON
    with open("js/settings.json") as f:
        data = json.load(f)

        # Accede al valore di DefaultMode
        default_mode_value = data['settings']['DefaultMode']

        print(default_mode_value)

