import os
from Suspension import ResumeProcesses
from Import import get_current_power_plan
import screen_brightness_control as sbc
import subprocess
from Conversione import GetCpuMaxClock
from findHexId import findId
#Funzione di emergenza in caso il programma crashi HyperSave ON
def Emergency() -> None:
    current_plan = get_current_power_plan()
    x = subprocess.getoutput(["powershell.exe","Get-ComputerInfo","-Property","PowerPlatformRole"])
    if not "Desktop" in x:
        britghtnessValues= sbc.get_brightness()
        prevBright = int(britghtnessValues[0])
        os.system(f'powershell -Command "(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,{prevBright})"')
    os.system(f'powercfg -setactive {current_plan}')
    os.system(f"powercfg -setdcvalueindex {findId()} SUB_PROCESSOR PROCFREQMAX {GetCpuMaxClock()}")


    ResumeProcesses()

Emergency()
